import {} from "../types/types";
const initialState = {};
const mainReducer = (state = initialState, action) => {
  switch (action.type) {
    default:
      return state;
  }
};
export default mainReducer;
